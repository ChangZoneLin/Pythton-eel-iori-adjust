import eel

eel.init('Web')

def print_return(n):
    print('Return from JavaScript',n)


eel.start('main.html')


#eel.js_what_year()(print_return)
eel.Update_DateTime()(print_return)


while True:     
    eel.sleep(7)


    
    

    


    

